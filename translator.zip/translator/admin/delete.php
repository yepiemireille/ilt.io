
<?php 

     include("../db/config.php");

     if (isset($_GET['id'])) {
     	
     	$id = $_GET['id'];
     	$query = "DELETE FROM users WHERE id = $id";
     	$result = mysqli_query($con, $query);
     	if (!result) {
     		die("Query Failed");
     	}

     	$_SESSION['message'] = 'Task Removed succesfully';
     	$_SESSION['message_type'] = 'danger';

     	header("Location: admin.php");
     }


 ?>