<?php session_start();

include_once('../db/config.php');

if(isset($_SESSION['username'])){
  $username = $_SESSION['username']; 
  $role = $_SESSION['role'];

}else{
  echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; 
    echo ' </script>';
}

?>

<?php include("../includes/header.php") ?>
<br><br>

<div class="chip heading text-center text-uppercase text-black mb-3">
  Bienvenue : <?php echo $role ; ?> <?php echo $username ; ?> <br></br>
</div>

<center><h1>Listes des utilisateurs</h1></center>
  <div class="container p-4">
    <div class="row">

      <div class="col-md-12">
        <table class="table table-bordered">
          <thead>
            <tr>
              <th>Nom & Prénoms</th>
              <th>Email</th>
              <th>Role</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php 

              $query = "SELECT * FROM users";
              $result_tasks = mysqli_query($con, $query);

              while($row = mysqli_fetch_array($result_tasks)){ ?>
                            <tr>
                              <td><?php echo $row['username'] ?></td>
                              <td><?php echo $row['email'] ?></td>
                              <td><?php echo $row['role'] ?></td>
                              <td><?php echo $row['date'] ?></td>
                              <td>
                                <a href="edit.php?id=<?php echo $row['id']?>" class="btn btn-secondary">
                                  <i class="fas fa-marker">Edit</i> 
                                </a>
                                <a href="delete.php?id=<?php echo $row['id']?>" class="btn btn-danger">
                                  <i class="far fa-trash-alt">Delete</i>
                                </a>
                              </td>
                            </tr>
              <?php } ?>

            
          </tbody>
        </table>
      </div>
    </div>
  </div>

<?php include("../includes/footer.php") ?>

