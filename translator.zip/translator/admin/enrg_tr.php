
  
<?php

include("../db/config.php");

     if (isset($_POST['Enregistrer'])) {
     	$username = $_POST['username'];
          $email = $_POST['email'];
          $password = md5($_POST['password']);
          $role = $_POST['role'];
     	
     	$query = "INSERT INTO users (username, email, password, role) VALUES ('$username', '$email', '$password', '$role')";
     	$result = mysqli_query($con, $query);
     	if (!$result) {
     		die("Query Failed");
     	}

     	$_SESSION['message'] = 'enregistrement reussie succesfully';
     	$_SESSION['message_type'] = 'success';

     	header("Location: enrg.php");
     }

 ?>