<?php
session_start();
?>

<?php
include("../db/config.php");

if (isset($_GET['id'])){

$id = $_GET['id'];
$query = "SELECT * FROM users WHERE id = $id";
$result = mysqli_query($con, $query);
if (mysqli_num_rows($result) == 1) {
     $row = mysqli_fetch_array($result);
    $username = $row['username'];
    $email = $row['email'];
    $role = $row['role'];
}
 
}

if (isset($_POST['Modifier'])){
    $id = $_GET['id'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $role = $_POST['role'];

     $query = "UPDATE users SET username = '$username', email = '$email', password = '$password', role = '$role' WHERE id = $id";
     mysqli_query($con, $query);
     header("Location: admin.php");

}
?>


<?php include("../includes/header.php") ?>

<center><h3>Modifier un utilisateur</h3></center><br>
<div class="container p-4">
     <div class="row">
          <div class="col-md-4 mx-auto">
               <div class="card card-body">
                    <form id="myForm" action="edit.php?id=<?php echo $_GET['id']; ?>" method="POST">

                         <div class="form-group">
                              <input type="text" name="username" value="<?php echo $username; ?>" class="form-control" placeholder="Nom & Prenom" required>
                         </div>

                         <div class="form-group">
                              <input type="email" name="email" value="<?php echo $email; ?>" class="form-control" placeholder="Email" required>
                         </div>

                         <div class="col form-group">
                              <select name="role" class="form-control" required>
                                   <option value="">Définir role</option>
                                   <option value="Administrateur">Administrateur</option>
                                   <option value="Operateur">Operateur</option>
                                   <option value="Superviseur">Superviseur</option>
                              </select>
                         </div>

                         <input type="submit" name= "Modifier" class="btn bg-success text-dark" value="Modifier">
                    </form>
               </div>
          </div> 
   </div>

</div>

<?php include("../includes/footer.php") ?>