


<?php include("../db/config.php") ?>
<?php include("../includes/header.php") ?>
<br><br>
<center><h3>Enregistrer un utilisateur</h3></center><br>
     <div class="container p-4">
          <div class="row">
               <div class="col-md-4 mx-auto">
                    <?php if(isset($_SESSION['message'])) { ?>
                         <div class="alert alert-<?= $_SESSION['message_type'];?> alert-dismissible fade show" role="alert">
                              <?= $_SESSION['message'];?>
                              <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                   <span aria-hidden="true">&times;</span>
                              </button>
                         </div>
                    <?php session_unset();} ?>
                    <div class="card card-body justify-content-center">
                         <form action="enrg_tr.php" method="POST">
                              <div class="form-group">
                                   <input type="text" name="username" class="form-control" placeholder="entrer votre nom et prenom" autofocus>
                              </div>

                              <div class="form-group">
                                   <input type="email" name="email" class="form-control" placeholder="entrer votre mail" autofocus>
                              </div>

                              <div class="form-group">
                                   <input type="password" name="password" class="form-control" placeholder="entrer votre mot de passe" autofocus>
                              </div>

                              <div class="form-group">
                                <select name="role" class="form-control" required>
                                  <option value="">Définir role</option>
                                  <option value="Administrateur">Administrateur</option>
                                  <option value="Operateur">Operateur</option>
                                  <option value="Superviseur">Superviseur</option>
                                </select>
                              </div>

                              <input type="submit" class="btn btn-success btn-block" name="Enregistrer" value="Enregistrer">

                              <!--    <input type="submit" value="Enregistrer" name="Enregistrer" class="btn btn-success">     -->
                         </form>
                    </div>
               </div>
          </div>
     </div>

<?php include("../includes/footer.php") ?>





   