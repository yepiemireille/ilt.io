<?php session_start();

include_once('db/config.php');

if(isset($_SESSION['username'])){
  $username = $_SESSION['username']; 
  $role = $_SESSION['role'];

}else{
  echo '<script language="Javascript">';
    echo 'document.location.replace("./logout.php")'; 
    echo ' </script>';
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <title>Dashboard</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/7cb0e7c261.js" crossorigin="anonymous"></script>
 
  <style>

    body {font-family: "Lato", sans-serif;}

    .sidebar {
      height: 100%;
      width: 180px;
      position: fixed;
      z-index: 1;
      top: 0;
      left: 0;
      background-color: #3E844A;
      overflow-x: hidden;
      padding-top: 16px;
    }

    .sidebar a {
      padding: 6px 8px 6px 16px;
      text-decoration: none;
      font-size: 15px;
      color: #FFFFFF;
      display: block;
    }

    .sidebar a:hover {
      color: #183B14;
    }

    .main {
      margin-left: 180px; 
      padding: 0px 10px;
    }

    @media screen and (max-height: 450px) {
      .sidebar {padding-top: 15px;}
      .sidebar a {font-size: 18px;}
    }


    .chip {
        display: inline-block;
        padding: 0 80px;
        height: 50px;
        font-size: 16px;
        line-height: 50px;
        border-radius: 25px;
        background-color: #000000;
    }

    .chip img {
        float: left;
        margin: 0 10px 0 -80px;
        height: 50px;
        width: 50px;
        border-radius: 50%;
    }

  table {font-size: 13px;}

  thead {font-weight: bold;}

</style>
</head>

<body>

  


   <center>Bienvenue : <?php echo $role ; ?> <?php echo $username ; ?></center>  <br></br>
 

    <center><h2>Table des traductions</h2></center>
    <div class="row">
    <div class="col-md-12 offset-md-2">
    <table class="table table-responsive table-bordered table-hovered">
    <thead>
    <tr>
      <td>texte</td>
      <td>langue d'origine</td>
      <td>traduction</td>
      <td>langue de traduction</td>
      <td>Fichier audio</td>
      <td>Date</td>
      <td>Option</td>
    </tr>
    </thead>
    <tbody>
    <?php        
      include_once('db/config.php');
      $sql = "SELECT texte1, langue_start, texte2, langue_end, audio, datec FROM data";
      $result_text = mysqli_query($con,$sql);
      while($row = mysqli_fetch_array($result_text)) { ?>
    <tr>
    <td><?php echo $row['texte1'] ?></td>
    <td><?php echo $row['langue_start'] ?></td>
    <td><?php echo $row['texte2'] ?></td>
    <td><?php echo $row['langue_end'] ?></td>
    <td>
      <audio controls>
        <source src="<?php echo $row['audio'] ?>" type="audio/mpeg">
      </audio>
    </td>
    <td><?php echo $row['datec'] ?></td>
    <td>
    <a href="edit_maudio.php?id=<?php echo $row['id']?>" class="btn btn-success"> <i class="fas fa-edit"></i></a>
    <a href="del_maudio.php?id=<?php echo $row['id']?>" class="btn btn-primary"> <i class="far fa-trash-alt"></i></a>
    </td>
    </tr>
    <?php } ?>
    </tbody>
    </table>
    </div>
    </div><br><br><br><br>

    

</body>
</html> 
