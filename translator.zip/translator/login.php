<?php
session_start();
?>

<!DOCTYPE html>
<html>
    <head>
      <meta http-equiv="CONTENT-TYPE" content="text/html; charset=UTF-8">
      <link rel="stylesheet" href="css/style.css"
      <!-- CSS only -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous"> 
      <!-- CSS only --> 
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">        
      <title>page de connexion</title>
   </head>
   <body> 
      <div class="header">        
      <h2>Connexion</h2>           
      </div>

      <form method="post" action="login.php"> 	
           
        <div class="input-group"> 		          
          <label>Email</label> 		           
          <input type="email" name="email" placeholder="Saisir votre email" required>
        </div> 

        <div class="input-group">              
          <label>Role</label>
          <select class="form-control" name ="role" required>
          <option value="" >Choisir</option>
          <option value="Superviseur">Superviseur</option>
          <option value="Administrateur">Administrateur</option>
          <option value="Opérateur de saisie">Opérateur</option>
          </select>
        </div>	
           
        <div class="input-group"> 		               
          <label>Password</label> 		              
          <input type="password" name="password" placeholder="Saisir votre mot de passe" required>
        </div> 		
           
        <div class="input-group"> 		               
          <br>
          <input type="submit" value="Connection" name="Connection" class="btn btn-success">
        </div> 

      </form>
        
        
        
     <?php include('includes/footer.php'); ?>    
        
        
        
        
        
        
        
          
          
          
          <br><br>

  <?php
include_once('db/config.php');

if(isset($_POST['Connection'])){
$email = $_POST['email'];
$password = md5($_POST['password']);

$sql = "SELECT * FROM users WHERE email = '$email' AND password = '$password' ";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
  
  $row = mysqli_fetch_assoc($result);
  $username = $row["username"];
  $role = $row["role"];
   $_SESSION['username'] = $username;
   $_SESSION['role'] = $role;


   header("Location: admin/admin.php");
  
    } else {
      // echo "Error: " . $sql . "<br>" . mysqli_error($con);
      echo " Email ou mot de passe incorrect " ;
    }

    }else{ 
  
    }


    mysqli_close($con);

    ?> 
        
        
        
       