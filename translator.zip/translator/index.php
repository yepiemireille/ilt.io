<?php
session_start();
?>

<?php include("includes/header1.php") ?>
<?php include('db/config.php'); ?>

<div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
    <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="img/4.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Bienvenu sur ILT</h5>
        <p>Votre site de traduction en langue locale ivoirienne.</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/5.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <strong><h5 style="color: black;">Traduction rapide</h5></strong> 
        <p style="color: black;">Avec ILT(Ivoire Language Translator), vous avez la possibilité de traduire vos mots ou phrases en toutes sorte de langue ivoirienne en moins d'une minute</p>
      </div>
    </div>
    <div class="carousel-item">
      <img src="img/6.jpg" class="d-block w-100" alt="...">
      <div class="carousel-caption d-none d-md-block">
        <h5>Apprendre plusieurs langues</h5>
        <p>Avec ILT vous pouvez apprendre plusieurs langues en tout temps et en tout lieux</p>
      </div>
    </div>
  </div>
   
  <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>

<!-- ************************************************************* --><br><br>
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <div class="form-group" rows="4">
          <select class="form-control" name ="langue_start" id ="langue_start" required>
          <option value="" >Sélectionner une langue</option>
            <?php
              $sql = "SELECT * FROM langues";
              $result = mysqli_query($con, $sql);
              while ($row = mysqli_fetch_array($result)) {
                echo '<option>'.$row['langue'].'</option>';
              }
            ?> 
          </select>
        </div>
          <textarea id="mytext">French English</textarea>

          <input type="file" id="avatar" name="avatar" accept="image/png, image/jpeg">

           <label>
          <span>Voice</span>
          <select id="voiceOptions"></select>
        </label>
        <label>
          <span>Volume</span>
          <input type="range" id="volumeSlider" min="0" max="1"  step="0.1" value="0.5" name="">
        </label>
        </div>
        <div class="col-md-6">
          <div class="form-group" rows="4">
          <select class="form-control" name ="langue_end" id ="langue_end" required>
          <option value="" >Sélectionner une langue</option>
            <?php
              $sql = "SELECT * FROM langues";
              $result = mysqli_query($con, $sql);
              while ($row = mysqli_fetch_array($result)) {
                echo '<option>'.$row['langue'].'</option>';
              }
            ?> 
          </select>
        </div>
          <textarea id="mytext">langue ivoirienne</textarea>
           <button class="button"  onclick='speak();'> Traduire</button>
        </div>
      </div>
    </div>



<!-- ************************************************************* -->
   
      <div class="container">
        
       
         
       </div>
        
       <script type="text/javascript">
        function  compatibility()
        {
          if (!('speechSynthesis' in window))
          {
            alert('your browser is not support');
          }
        };
           compatibility();
          var voiceOptions = document.getElementById('voiceOptions');
           var volumeSlider = document.getElementById('volumeSlider');
            var mytext = document.getElementById('mytext');

            var voiceMap =[];


            function loadvoices()
            {
              var voices = speechSynthesis.getVoices();
              for (var i= 0; i < voices.length  ;  i++)
               {
                 var voice = voices[i];
                 var option =document.createElement('option');
                 option.value = voice.name;
                 option.innerHTML = voice.name;
                 voiceOptions.appendchild(option);

                 voiceMap[voice.name]= voice ;
              };
               window.speechSynthesis.onvoiceschanged = function (e)
            {
               loadvoices();
            };
          };

           
            function speak()
            {
              var msg = new SpeechSynthesisUtterance();
               msg.volume=volumeSlider.value;
               msg.voice =voiceMap[voiceOptions.value] ;
               msg.text =mytext.value;

               window.speechSynthesis.speak(msg);
            };
      
       </script>
<?php include("includes/footer.php") ?>